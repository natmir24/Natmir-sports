export interface Game {
  id: string;
  title: string;
  category: "Slots" | "Table" | "Live" | "Jackpot" | "Crash" | "Keno";
  image: string;
  hot?: boolean;
  new?: boolean;
}

export const GAMES: Game[] = [
  { id: "1", title: "Royal Flush Poker", category: "Table", image: "linear-gradient(135deg, #2C3E50 0%, #000000 100%)", hot: true },
  { id: "2", title: "Golden Empire Slots", category: "Slots", image: "linear-gradient(135deg, #F1C40F 0%, #B7950B 100%)", hot: true },
  { id: "3", title: "Midnight Blackjack", category: "Table", image: "linear-gradient(135deg, #1A252F 0%, #000000 100%)" },
  { id: "4", title: "Live Roulette VIP", category: "Live", image: "linear-gradient(135deg, #C0392B 0%, #8E44AD 100%)", new: true },
  { id: "5", title: "Zeus Lightning", category: "Slots", image: "linear-gradient(135deg, #3498DB 0%, #2980B9 100%)" },
  { id: "6", title: "Mega Moolah Jackpot", category: "Jackpot", image: "linear-gradient(135deg, #F39C12 0%, #D35400 100%)", hot: true },
  { id: "7", title: "Baccarat Prestige", category: "Table", image: "linear-gradient(135deg, #16A085 0%, #27AE60 100%)" },
  { id: "8", title: "Dragon's Fortune", category: "Slots", image: "linear-gradient(135deg, #E74C3C 0%, #C0392B 100%)", new: true },
  { id: "9", title: "Aviator Crash", category: "Crash", image: "linear-gradient(135deg, #C0392B 0%, #1a1a1a 100%)", hot: true },
  { id: "10", title: "Space X Rocket", category: "Crash", image: "linear-gradient(135deg, #2980B9 0%, #111 100%)", new: true },
  { id: "11", title: "Royal Keno 80", category: "Keno", image: "linear-gradient(135deg, #8E44AD 0%, #2c3e50 100%)" },
  { id: "12", title: "Golden Ball Keno", category: "Keno", image: "linear-gradient(135deg, #D4AF37 0%, #000 100%)", hot: true },
];

export const CATEGORIES = ["All", "Slots", "Table", "Live", "Crash", "Keno", "Jackpot"];
